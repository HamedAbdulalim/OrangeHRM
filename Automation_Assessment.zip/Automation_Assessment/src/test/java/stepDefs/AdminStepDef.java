package stepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;
import pages.P01_login;
import pages.P02_AdminTab;
import pages.P03_RecordsTab;
import pages.P04_AddUser;

import static stepDefs.Hooks.driver;

public class AdminStepDef{

    P01_login login ;
    P02_AdminTab adminTab;
    P03_RecordsTab adminTabxx;
    P04_AddUser AddUser;
    @Given("user Login to System")
    public void loginxxxx( ){
        login = new P01_login(driver);
        login.loginSteps("Admin","admin123");
       }

    @When("user click on AdminTab")
    public void clickAdminTab() throws InterruptedException {
        adminTab = new P02_AdminTab(driver);
        adminTab.ClickAdmin();
     // throw new io.cucumber.java.PendingException();
    }

    @Then("Count Records number")
    public void GetNumberOfRecord() throws InterruptedException {
        adminTabxx = new P03_RecordsTab(driver);
        adminTabxx.NoOfRecordss();
        adminTabxx.AddRecord();

    }

    @And("Fill the required data")
    public void fillTheRequiredData() throws InterruptedException {
        AddUser = new P04_AddUser(driver);
        AddUser.UserRole();
        AddUser.UserStatus();
        AddUser.EmployeeName();
        AddUser.EUserName();
        AddUser.EnterPassword();

      //  throw new io.cucumber.java.PendingException();

    }

    @Then("Click on save button")
    public void clickOnSaveButton() throws InterruptedException {
        AddUser.clickSave();
    }

    @And("Number of Records increased by one")
    public void numberOfRecordsIncreasedByOne() throws InterruptedException {
        adminTabxx = new P03_RecordsTab(driver);
        adminTabxx.RecordIncrease();


    }

    @When("search for user")
    public void searchForUser() throws InterruptedException {
        adminTabxx = new P03_RecordsTab(driver);
        adminTabxx.SearchUser();
    }

    @Then("Delete User")
    public void deleteUser() throws InterruptedException {
        adminTabxx = new P03_RecordsTab(driver);
        adminTabxx.DeleteUser();
    }

    @And("Number of Records decreased by one")
    public void numberOfRecordsDecreasedByOne() throws InterruptedException {
        adminTab = new P02_AdminTab(driver);
        adminTab.ClickAdmin();
        adminTabxx = new P03_RecordsTab(driver);
        adminTabxx.NoOfRecordss();


    }
}

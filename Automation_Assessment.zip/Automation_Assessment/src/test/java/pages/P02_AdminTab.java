package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import stepDefs.Hooks;

public class P02_AdminTab {
    // Constructor
    private WebDriver driver;
    public P02_AdminTab(WebDriver driver){
        PageFactory.initElements(Hooks.driver, this);
    }

    // Locators

    @FindBy(css = "#app > div.oxd-layout > div.oxd-layout-navigation > aside > nav > div.oxd-sidepanel-body > ul > li:nth-child(1) > a > svg")
    public WebElement clickAdminx;


  public void ClickAdmin() throws InterruptedException {
    Thread.sleep(5000);
    clickAdminx.click();
    }

}
package pages;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import stepDefs.Hooks;

public class P03_RecordsTab {

    String SUser = "Hamed_0003";
    // Constructor
    private WebDriver driver;
    private int RecordBefore;

    public P03_RecordsTab(WebDriver driver) {
        PageFactory.initElements(Hooks.driver, this);
    }

    // --------------------------Locators--------------
    @FindBy(xpath = "//span[@class='oxd-text oxd-text--span']")
    public WebElement NoOfRecords;
    @FindBy(xpath = "//button[contains(.,'Add')]")
    public WebElement AddRecordBtn;
    @FindBy(xpath = "/html/body/div/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[1]/div/div[2]/input")
    public WebElement searchHolder;
    @FindBy(xpath = "//button[@type='submit'][contains(.,'Search')]")
    public WebElement SearchBtn;

    @FindBy(xpath = "/html/body/div/div[1]/div[2]/div[2]/div/div[2]/div[3]/div/div[2]/div/div/div[2]/div")
    public WebElement USerResult;

    @FindBy(xpath = "//i[contains(@class,'oxd-icon bi-trash')]")
    public WebElement DelBTN;

    @FindBy(xpath = "//button[contains(.,'Yes, Delete')]")
    public WebElement ConfirmDel;

    //  @FindBy(xpath = "(//div[contains(.,'"+SUser+"')])[13]")
    //  public WebElement USerResult;
    //--------------------------methods----------------

    public int NoOfRecordss() throws InterruptedException {
        Thread.sleep(2000);
        String Num = NoOfRecords.getText();
        String value = StringUtils.substringBetween(Num, "(", ")");
        RecordBefore = Integer.parseInt(value);
        System.out.println("Number of Records: "+RecordBefore);
        return RecordBefore;
    }

    public void AddRecord() throws InterruptedException {
        Thread.sleep(3000);
        AddRecordBtn.click();
    }

    public void RecordIncrease() throws InterruptedException {
        Thread.sleep(5000);
        String Num2 = NoOfRecords.getText();
        String value2 = StringUtils.substringBetween(Num2, "(", ")");
        int RecordAfter = Integer.parseInt(value2);
        System.out.println("Number of Records after Addition: "+(RecordAfter - RecordBefore));
        if ((RecordAfter - RecordBefore) == 1) {
            System.out.println(" Record increased by ");
        }
    }

    public void SearchUser() throws InterruptedException {
        searchHolder.sendKeys(SUser);
        SearchBtn.click();
        Thread.sleep(2000);


        System.out.println("User: " + USerResult.getText() + " Existed Successfully");
        Assert.assertEquals(USerResult.getText(), SUser);
    }

    public void DeleteUser() throws InterruptedException {
        Thread.sleep(2000);
        DelBTN.click();
        Thread.sleep(2000);
        ConfirmDel.click();

    }
}

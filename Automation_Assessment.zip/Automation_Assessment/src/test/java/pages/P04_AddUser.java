package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import stepDefs.Hooks;

public class P04_AddUser {
    // Constructor
    private WebDriver driver;
    public P04_AddUser(WebDriver driver){
        PageFactory.initElements(Hooks.driver, this);
    }

    // --------------------------Locators--------------
    @FindBy(xpath = "(//div[@class='oxd-select-text-input'])[1]")
    public  WebElement SelectUserRole;
    @FindBy(xpath = "(//div[contains(@role,'option')])[3]")
    public WebElement userOption;
    @FindBy(xpath = "(//div[contains(@tabindex,'0')])[2]")
    public  WebElement SelectUserStatus;
    @FindBy(xpath = "(//div[contains(.,'Enabled')])[13]")
    public WebElement userStatus;
    @FindBy(xpath = "//input[contains(@placeholder,'Type for hints...')]")
    public WebElement EmployeeName;
    @FindBy(xpath = "(//div[@role='option'])[2]")
    public WebElement SEmployeeName;
    @FindBy(xpath = "(//input[@class='oxd-input oxd-input--active'])[2]")
    public WebElement UserName;
    @FindBy(xpath = "(//input[@type='password'])[1]")
    public WebElement password;
    @FindBy(xpath = "(//input[@type='password'])[2]")
    public WebElement ConfirmPassword;
    @FindBy(xpath = "//button[contains(.,'Save')]")
    public WebElement SaveBtn;


    //--------------------------methods----------------


    public void UserRole() throws InterruptedException {
        Thread.sleep(3000);
          SelectUserRole.click();
          userOption.click();
    }
    public void UserStatus()  {
        SelectUserStatus.click();
        userStatus.click();
    }
    public void EmployeeName() throws InterruptedException {
        EmployeeName.sendKeys("M");
        Thread.sleep(5000);
        SEmployeeName.click();
    }
    public void EUserName() throws InterruptedException {
        Thread.sleep(2000);
        UserName.sendKeys("Hamed_0003");
    }
    public void EnterPassword() throws InterruptedException {
        password.sendKeys("Hamed.123");
        ConfirmPassword.sendKeys("Hamed.123");
        Thread.sleep(2000);
    }

    public void clickSave() throws InterruptedException {
        SaveBtn.click();
        Thread.sleep(2000);

    }
}
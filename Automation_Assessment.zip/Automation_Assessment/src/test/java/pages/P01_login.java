package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import stepDefs.Hooks;

public class P01_login {

    // Constructor
    public P01_login(WebDriver driver) {
        PageFactory.initElements(Hooks.driver, this);
    }

    @FindBy (xpath = "//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/h5")
    public WebElement loginTile;
    @FindBy (name = "username")
    public WebElement enterUserName;


    @FindBy (name = "password")
    public WebElement enterPassword;

    @FindBy(xpath = "//button[@type='submit']")
    public WebElement loginBtn;

    @FindBy (className = "ico-account")
    public WebElement myAccountTab;

    @FindBy (className = "message-error")
    public WebElement unSuccessMsg;

    public void loginSteps(String email, String password) {
        enterUserName.sendKeys(email);
        enterPassword.sendKeys(password);
        loginBtn.click();
    }
 public void LoginPageAssertion () throws InterruptedException {


   Assert.assertEquals(loginTile.getText(),"Login");
 }





}
